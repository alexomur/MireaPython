import setuptools

setuptools.setup(
    name='ObjectParser', # Имя пакета
    version='0.0.2', # Версия пакета
    author='DrBright',
    author_email='alexomur111@gmail.com',
    description='Object Parser made to parse yml and json data directly to objects by annotations',
    packages=setuptools.find_packages(),
)
